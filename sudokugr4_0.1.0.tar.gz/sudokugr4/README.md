# Sudoku Game - Groupe 4
Bibliothèque pour générer, valider, résoudre des puzzles sudoku

<p align="center">
  <img src="https://github.com/abderrahim-ait/Projet_R-Groupe4/blob/main/Suduko.png" width="400" title="Suduko">
</p>



PROJET M1 SSD -- Programmation R

## EDITEURS
__AIT__ __MOULAY__ __ABDERRAHIM__ 

__JIAYUE__ __YUAN__

## INTRODUCTION
L’objectif du projet est de créer une bibliothèque R, incluant une application Shiny, contenant des fonctions permettant de :
- générer aléatoirement des grilles de Sudoku complètes
- résoudre des grilles de Sudoku incomplètes
- générer des grilles de Sudoku incomplètes associées à un niveau de difficulté
