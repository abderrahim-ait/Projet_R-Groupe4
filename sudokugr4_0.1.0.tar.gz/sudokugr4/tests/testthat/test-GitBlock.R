test_that("multiplication works", {
  res<-GitBlock(2,2)
  expect_equal(res,1)
})
