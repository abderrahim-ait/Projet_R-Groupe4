library(testthat)
library(sudokugr4)

test_check("sudokugr4")
